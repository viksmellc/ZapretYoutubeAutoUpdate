﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Threading.Tasks;

namespace ZapretYoutubeAutoUpdate
{
    internal class Program
    {
        private const string VersionUrl = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/main/.service/version.txt";
        private const string ArchiveUrl = "https://github.com/Flowseal/zapret-discord-youtube/archive/refs/heads/main.zip";
        private const string DefaultBatName = "general (FAKE TLS AUTO).bat";

        static async Task<int> Main(string[] args)
        {
            try
            {
                Console.WriteLine("🚀 ZapretYoutubeAutoUpdate v1.2");
                Console.WriteLine("Остановка winws.exe → загрузка → запуск .bat\n");

                // 🔹 0. Остановка всех winws.exe — критически важно при смене режима
                Console.WriteLine("⏹️  Проверка и остановка winws.exe (если запущен)...");
                bool winwsFound = false;
                foreach (var proc in Process.GetProcessesByName("winws"))
                {
                    winwsFound = true;
                    try
                    {
                        string exeName = Path.GetFileName(proc.MainModule?.FileName ?? "unknown");
                        Console.WriteLine($"   → PID {proc.Id}: {exeName}");
                        proc.Kill();
                        proc.WaitForExit(3000); // ждём до 3 секунд
                        Console.WriteLine("   ✅ Процесс завершён.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"   ⚠️  Не удалось завершить PID {proc.Id}: {ex.Message}");
                    }
                }
                if (!winwsFound)
                {
                    Console.WriteLine("   ➜ winws.exe не обнаружен.");
                }

                // 🔹 1. Определяем имя .bat-файла из аргумента или по умолчанию
                string batFileName = args.Length > 0 && !string.IsNullOrWhiteSpace(args[0])
                    ? args[0].Trim('\"', '\'')
                    : DefaultBatName;

                Console.WriteLine($"\n🎯 Целевой файл: '{batFileName}'");

                // 🔹 2. Проверка прав администратора (для информации)
                var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                bool isElevated = principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
                Console.WriteLine(isElevated
                    ? "🛡️  Запущено от администратора."
                    : "⚠️  Запущено без прав администратора.");

                // 🔹 3. Получаем номер версии
                Console.WriteLine("\n🔁 Получаем актуальную версию...");
                using var httpClient = new HttpClient();
                string version = (await httpClient.GetStringAsync(VersionUrl)).Trim();
                if (string.IsNullOrWhiteSpace(version))
                    throw new InvalidOperationException("Не удалось получить номер версии.");

                Console.WriteLine($"✅ Версия: {version}");

                // 🔹 4. Пути
                string exeDir = AppDomain.CurrentDomain.BaseDirectory;
                string versionDir = Path.Combine(exeDir, version);
                string extractedFolderName = "zapret-discord-youtube-main";
                string batPath = Path.Combine(versionDir, extractedFolderName, batFileName);

                // 🔹 5. Проверка / загрузка при отсутствии
                if (Directory.Exists(versionDir) && File.Exists(batPath))
                {
                    Console.WriteLine($"📁 Папка '{version}' и файл '{batFileName}' найдены. Пропускаем загрузку.");
                }
                else
                {
                    Console.WriteLine($"🆕 Папка '{version}' или файл '{batFileName}' отсутствуют — начинаем загрузку...");

                    Directory.CreateDirectory(versionDir);
                    string archivePath = Path.Combine(versionDir, "main.zip");

                    Console.WriteLine("📥 Скачиваем архив...");
                    using (var response = await httpClient.GetAsync(ArchiveUrl, HttpCompletionOption.ResponseHeadersRead))
                    {
                        response.EnsureSuccessStatusCode();
                        await using var stream = await response.Content.ReadAsStreamAsync();
                        await using var fileStream = new FileStream(archivePath, FileMode.Create, FileAccess.Write, FileShare.None);
                        await stream.CopyToAsync(fileStream);
                    }

                    Console.WriteLine("📦 Распаковка архива...");
                    ZipFile.ExtractToDirectory(archivePath, versionDir, overwriteFiles: true);
                    File.Delete(archivePath);
                }

                // 🔹 6. Запуск .bat
                if (!File.Exists(batPath))
                {
                    Console.WriteLine($"\n❌ Файл не найден: {batPath}");
                    Console.WriteLine("   Убедитесь, что такой .bat существует в репозитории.");
                    return -2;
                }

                Console.WriteLine($"\n▶️ Запускаем: {batFileName}");
                var startInfo = new ProcessStartInfo
                {
                    FileName = batPath,
                    UseShellExecute = true,
                    WorkingDirectory = Path.GetDirectoryName(batPath)!,
                };

                Process.Start(startInfo);
                Console.WriteLine("✅ Запуск выполнен. Программа завершает работу.");
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {ex.Message}");
                if (ex.InnerException != null)
                    Console.WriteLine($"   → {ex.InnerException?.Message}");
                return -1;
            }
        }
    }
}
